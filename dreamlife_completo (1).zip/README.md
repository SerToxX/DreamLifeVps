# 🎌 Dream Life — Plataforma E-commerce de Anime

Sistema completo: **Tienda online + Panel de administración + POS** para tienda de merchandising anime.

## ✨ Características

- **Frontend:** Next.js 14 + TypeScript + Tailwind CSS + Zustand
- **Backend:** NestJS + Prisma + MySQL 8.0 + JWT
- **Diseño:** Minimalista B/N con modo oscuro toggleable
- **100% responsive** (móvil, tablet, desktop)
- **Multi-ubicación**: 4 locales preconfigurados
- **Gestión por SKU**: búsqueda y manejo por código único
- **Roles:** Admin, Worker (trabajador), Cliente

## 🚀 Instalación rápida

```bash
# 1. Levantar todo
docker compose up -d --build

# 2. Esperar que MySQL esté listo (60s aprox)
# 3. Crear tablas y datos demo:
docker exec dreamlife_api npx prisma db push
docker exec dreamlife_api npx tsx prisma/seed.ts
```

## 🌐 Accesos

- **Tienda:**    http://localhost:3000
- **Admin:**     http://localhost:3000/login (marca "Soy administrador")
- **API:**       http://localhost:3001/api/v1
- **API Docs:**  http://localhost:3001/api/docs

## 🔑 Credenciales (todas con la misma contraseña: `Racer2001.`)

| Rol | Email | Contraseña |
|---|---|---|
| Admin | admin@dreamlife.com | Racer2001. |
| Worker | worker@dreamlife.com | Racer2001. |
| Cliente | cliente@demo.com | Racer2001. |
| Cliente | ana@demo.com | Racer2001. |

## 🏪 Ubicaciones (multi-local)

1. Tienda Central — Lima
2. Tienda Miraflores
3. Almacén Principal
4. Tienda Online

## 🎨 Modo oscuro

Toggle en la esquina superior derecha (botón sol/luna). Se persiste en localStorage.

## 📦 Productos

Cada producto tiene **items con SKU único** (ej: NRT-M-001, DBZ-L-001).
La búsqueda en catálogo, productos admin e inventario funciona por SKU.

## 🔄 Reset de datos

```bash
docker compose down -v
docker compose up -d --build
docker exec dreamlife_api npx prisma db push
docker exec dreamlife_api npx tsx prisma/seed.ts
```
